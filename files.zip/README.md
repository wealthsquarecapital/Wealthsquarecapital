# Wealth Square Capital — Website

A single-page static site (`index.html`, no build step needed) covering Home, Services, About Us, Research, and Contact, with the finalized copy from the content doc.

## Deploy to GitHub Pages

1. Go to github.com and create a new repository (e.g. `wealthsquarecapital-site`). Keep it **public** (required for free GitHub Pages).
2. On the repo's main page, click **Add file → Upload files**, then drag in `index.html` (the logo is embedded directly in this file, so nothing else needs uploading alongside it).
3. Commit the upload to the `main` branch.
4. Go to the repo's **Settings → Pages**.
5. Under "Build and deployment," set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`. Save.
6. Wait 1–2 minutes — GitHub will give you a live URL like `https://<your-username>.github.io/wealthsquarecapital-site/`.
7. To use your own domain (wealthsquarecapital.com), add a `CNAME` file with your domain name to the repo, and point your domain's DNS to GitHub Pages per [GitHub's custom domain guide](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site).

## Notes before going live
- Replace the placeholder phone number, email, and office address in the Contact section.
- The contact form currently just shows a confirmation message — it isn't wired to actually send anywhere yet. For a real form, the simplest options are [Formspree](https://formspree.io) or [Netlify Forms](https://www.netlify.com/platform/core/forms/) (a few lines of markup, no backend needed).
- Have your compliance advisor review the disclaimers and service descriptions before publishing.
